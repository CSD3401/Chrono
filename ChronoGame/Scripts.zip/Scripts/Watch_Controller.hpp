#pragma once
#include "EngineAPI.hpp"
#include "ScriptSDK//UI.h"
/*
* Watch_Controller - Overlay swap + clock fill
* Press E to toggle between present (green) and past (blue).
* Clock drains while in past, refills while in present.
* Auto-switches back to present when depleted.
* ALL events/audio deferred to next frame to avoid crash.
*/

class Watch_Controller : public IScript {
public:
    GameObjectRef presentOverlayRef;
    GameObjectRef pastOverlayRef;
    GameObjectRef clockFillRef;

    Watch_Controller() {
        SCRIPT_GAMEOBJECT_REF(presentOverlayRef);
        SCRIPT_GAMEOBJECT_REF(pastOverlayRef);
        SCRIPT_GAMEOBJECT_REF(clockFillRef);
    }
    ~Watch_Controller() override = default;

    void Awake() override {}
    void Initialize(Entity entity) override {}

    void Start() override {
        if (presentOverlayRef.IsValid())
            m_presentOverlay = presentOverlayRef.GetEntity();
        else
            LOG_WARNING("Watch_Controller: presentOverlayRef not set.");

        if (pastOverlayRef.IsValid())
            m_pastOverlay = pastOverlayRef.GetEntity();
        else
            LOG_WARNING("Watch_Controller: pastOverlayRef not set.");

        if (clockFillRef.IsValid())
            m_clockFill = clockFillRef.GetEntity();
        else
            LOG_WARNING("Watch_Controller: clockFillRef not set.");

        isPast = false;
        fillValue = 1.0f;
        m_pendingEvent = PendingEvent::NONE;

        ApplyOverlayState();
        ApplyClockFill();

        LOG_INFO("Watch_Controller: Ready. Press E to toggle past/present.");
    }

    void Update(double deltaTime) override {
        float dt = static_cast<float>(deltaTime);

        // Fire deferred event from previous frame
        if (m_pendingEvent != PendingEvent::NONE) {
            if (m_pendingEvent == PendingEvent::ACTIVATED) {
                //Events::Send("ChronoActivated");
                Events::Send("Activated");
                PlayAudio("event:/SWITCH_TO_PAST");
                LOG_INFO("Watch_Controller: Deferred ChronoActivated sent.");
            }
            else if (m_pendingEvent == PendingEvent::DEACTIVATED) {
                //Events::Send("ChronoDeactivated");
                Events::Send("Deactivated");
                PlayAudio("event:/SWITCH_TO_PRESENT");
                LOG_INFO("Watch_Controller: Deferred ChronoDeactivated sent.");
            }
            m_pendingEvent = PendingEvent::NONE;
        }

        // Toggle on E press
        if (Input::WasKeyPressed('E')) {
            isPast = !isPast;
            ApplyOverlayState();

            // Defer event to next frame
            if (isPast)
                m_pendingEvent = PendingEvent::ACTIVATED;
            else
                m_pendingEvent = PendingEvent::DEACTIVATED;

            LOG_INFO("Watch_Controller: E pressed, isPast=" + std::to_string(isPast) + " (event deferred)");
        }

        // Drain in past, refill in present
        if (isPast) {
            fillValue -= 0.5f * dt;
            if (fillValue < 0.0f) {
                fillValue = 0.0f;
                isPast = false;
                ApplyOverlayState();
                m_pendingEvent = PendingEvent::DEACTIVATED;
                LOG_INFO("Watch_Controller: Depleted, forced to PRESENT (event deferred)");
            }
        }
        else {
            fillValue += 0.3f * dt;
            if (fillValue > 1.0f)
                fillValue = 1.0f;
        }

        ApplyClockFill();
    }

    void OnDestroy() override {}
    void OnEnable() override {}
    void OnDisable() override {}
    void OnValidate() override {}
    const char* GetTypeName() const override { return "Watch_Controller"; }
    void OnCollisionEnter(Entity other) override { (void)other; }
    void OnCollisionExit(Entity other) override { (void)other; }
    void OnCollisionStay(Entity other) override { (void)other; }
    void OnTriggerEnter(Entity other) override { (void)other; }
    void OnTriggerExit(Entity other) override { (void)other; }
    void OnTriggerStay(Entity other) override { (void)other; }

private:
    enum class PendingEvent { NONE, ACTIVATED, DEACTIVATED };

    Entity m_presentOverlay = 0;
    Entity m_pastOverlay = 0;
    Entity m_clockFill = 0;
    bool isPast = false;
    float fillValue = 1.0f;
    PendingEvent m_pendingEvent = PendingEvent::NONE;

    void ApplyOverlayState() {
        if (m_presentOverlay != 0)
            SetActive(!isPast, m_presentOverlay);
        if (m_pastOverlay != 0)
            SetActive(isPast, m_pastOverlay);
    }

    void ApplyClockFill() {
        if (m_clockFill != 0)
            NE::ECS::Command::SetUIImageFillAmount(m_clockFill, fillValue);
    }
};