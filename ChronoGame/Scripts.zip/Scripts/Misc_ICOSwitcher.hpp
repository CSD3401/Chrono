#pragma once
#include "EngineAPI.hpp"
/*
* Miscellaneous_ICOSwitcher:
* - Listens for ChronoActivated/ChronoDeactivated events
* - Toggles two referenced GameObjects (idle vs running)
* - Destroys itself if references are invalid
*/

class Misc_ICOSwitcher : public IScript {
public:
    Misc_ICOSwitcher() {
        //SCRIPT_GAMEOBJECT_REF(objectsIdle);
        //SCRIPT_GAMEOBJECT_REF(objectsRunning);
        SCRIPT_GAMEOBJECT_REF(presentObj);
        SCRIPT_GAMEOBJECT_REF(pastObj);
    }

    ~Misc_ICOSwitcher() override = default;

    // === Lifecycle Methods ===
    void Awake() override {
        RegisterEventListeners();
        LOG_INFO("Miscellaneous_ICOSwitcher: listeners registered");
    }

    void Initialize(Entity entity) override {}
    void Start() override {
        // Addition: Ensure a consistent initial state at play start (running on, idle off).
        
		// RF - Start the game in the present state aka presentObj - active  , pastObj - inactive
        //Activate();

        if (!CheckObjectsValid()) return;

        SetActive(true, presentObj.GetEntity());
        SetActive(false, pastObj.GetEntity());

        // Delay so everyone can register listeners first
        Coroutines::Handle h = Coroutines::Create();
        Coroutines::AddWait(h, 0.0f);
        Coroutines::AddAction(h, []() { Events::Send("TimePastDisabled", nullptr); });
        Coroutines::Start(h);
    }
    void Update(double deltaTime) override {}

    void OnDestroy() override {
        listeningEnabled = false;
    }

    // === Optional Callbacks ===
    void OnEnable() override {
        listeningEnabled = true;
        LOG_INFO("Miscellaneous_ICOSwitcher: enabled");
    }

    void OnDisable() override {
        listeningEnabled = false;
        LOG_INFO("Miscellaneous_ICOSwitcher: disabled");
    }

    void OnValidate() override {}

    const char* GetTypeName() const override {
        return "Miscellaneous_ICOSwitcher";
    }

    // === Collision Callbacks ===
    void OnCollisionEnter(Entity other) override { (void)other; }
    void OnCollisionExit(Entity other) override { (void)other; }
    void OnCollisionStay(Entity other) override { (void)other; }
    void OnTriggerEnter(Entity other) override { (void)other; }
    void OnTriggerExit(Entity other) override { (void)other; }
    void OnTriggerStay(Entity other) override { (void)other; }

private:
    //GameObjectRef objectsIdle; // list of past obj
    //GameObjectRef objectsRunning; // list of present obj
    GameObjectRef presentObj; // list of past obj -> put a empty parent to contain all present obj
    GameObjectRef pastObj; // list of past obj -> put a empty parent to contain all present obj
    bool eventsRegistered = false;
    bool listeningEnabled = false;

    void RegisterEventListeners() {
        if (eventsRegistered) {
            return;
        }

        Events::Listen("ChronoActivated", [this](void*) {
            if (!listeningEnabled) {
                LOG_INFO("Miscellaneous_ICOSwitcher: ChronoActivated ignored (disabled)");
                return;
            }
            Activate();
        });

        Events::Listen("ChronoDeactivated", [this](void*) {
            if (!listeningEnabled) {
                LOG_INFO("Miscellaneous_ICOSwitcher: ChronoDeactivated ignored (disabled)");
                return;
            }
            Deactivate();
        });

        eventsRegistered = true;
    }

    bool CheckObjectsValid() const {
        return presentObj.IsValid() && pastObj.IsValid();
    }

    void Activate() {
        if (!CheckObjectsValid()) {
            LOG_WARNING("Miscellaneous_ICOSwitcher: Invalid references on activate, destroying");
            Command::DestroyEntity(GetEntity());
            return;
        }

        LOG_INFO("Miscellaneous_ICOSwitcher: ChronoActivated -> present off, past on");
        SetActive(false, presentObj.GetEntity());
        SetActive(true, pastObj.GetEntity());

        // Send on next tick so scripts under pastObj have Awake() called + listeners registered
        Coroutines::Handle h = Coroutines::Create();
        Coroutines::AddWait(h, 0.0f);
        Coroutines::AddAction(h, []() { Events::Send("TimePastEnabled", nullptr); });
        Coroutines::Start(h);
    }

    void Deactivate() {
        if (!CheckObjectsValid()) {
            LOG_WARNING("Miscellaneous_ICOSwitcher: Invalid references on deactivate, destroying");
            Command::DestroyEntity(GetEntity());
            return;
        }

        LOG_INFO("Miscellaneous_ICOSwitcher: ChronoDeactivated -> present on, past off");
        SetActive(true, presentObj.GetEntity());
        SetActive(false, pastObj.GetEntity());

        // Send on next tick for consistency
        Coroutines::Handle h = Coroutines::Create();
        Coroutines::AddWait(h, 0.0f);
        Coroutines::AddAction(h, []() { Events::Send("TimePastDisabled", nullptr); });
        Coroutines::Start(h);
    }

};
