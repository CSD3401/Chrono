#pragma once
#include "EngineAPI.hpp"

/**
 * Interactable_Gate
 *
 * Simple gate that opens (deactivates) when player is within range and presses E.
 *
 * Setup:
 * 1. Add this script to your gate entity
 * 2. Assign playerRef in inspector (drag Player entity)
 * 3. Set interactionDistance (default: 5.0)
 * 4. Press E when near gate to open it
 */
class Interactable_Gate : public IScript {
public:
    Interactable_Gate() {
        SCRIPT_GAMEOBJECT_REF(playerRef);
        SCRIPT_FIELD(interactionDistance, Float);
        SCRIPT_FIELD(logInteractions, Bool);
    }

    ~Interactable_Gate() override = default;

    void Awake() override {}
    void Initialize(Entity entity) override {}

    void Start() override {
        gateEntity = GetEntity();

        if (!playerRef.IsValid()) {
            LOG_ERROR("Interactable_Gate: playerRef not assigned!");
        }

        if (interactionDistance <= 0.0f) {
            LOG_WARNING("Interactable_Gate: interactionDistance must be > 0, setting to 5.0");
            interactionDistance = 5.0f;
        }

        LOG_DEBUG("Interactable_Gate initialized - Distance: {}", interactionDistance);
    }

    void Update(double deltaTime) override {
        if (!playerRef.IsValid()) return;

        // Get player entity and positions
        Entity player = playerRef.GetEntity();
        Vec3 playerPos = GetPosition(GetTransformRef(player));
        Vec3 gatePos = GetPosition(GetTransformRef(gateEntity));

        // Calculate distance
        Vec3 delta = playerPos - gatePos;
        float distance = delta.Length();

        // Check if player is in range and presses E
        if (distance <= interactionDistance) {
            if (Input::WasKeyPressed('E')) {
                OpenGate();
            }
        }
    }

    void OnDestroy() override {}
    void OnEnable() override {}
    void OnDisable() override {}
    void OnValidate() override {}
    const char* GetTypeName() const override { return "Interactable_Gate"; }

    // === Collision Callbacks (required by IScript) ===
    void OnCollisionEnter(Entity other) override { (void)other; }
    void OnCollisionExit(Entity other) override { (void)other; }
    void OnCollisionStay(Entity other) override { (void)other; }
    void OnTriggerEnter(Entity other) override { (void)other; }
    void OnTriggerExit(Entity other) override { (void)other; }
    void OnTriggerStay(Entity other) override { (void)other; }

private:
    void OpenGate() {
        // Deactivate the gate
        SetActive(false, gateEntity);

        if (logInteractions) {
            LOG_DEBUG("Gate opened! Entity {} deactivated", gateEntity);
        }
    }

    // Exposed fields
    GameObjectRef playerRef;
    float interactionDistance = 5.0f;
    bool logInteractions = true;

    // Runtime
    Entity gateEntity = 0;
};