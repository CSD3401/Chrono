#pragma once
#include "EngineAPI.hpp"

/*
* Misc_TwoStateRotater
* Two-state rotation tween on a target entity, driven by public methods.
*/

class Misc_TwoStateRotater : public IScript {
public:
    Misc_TwoStateRotater() {
        SCRIPT_GAMEOBJECT_REF(target);
        SCRIPT_FIELD(rotationX1, Float);
        SCRIPT_FIELD(rotationX2, Float);
        SCRIPT_FIELD(duration, Float);
        SCRIPT_FIELD(startingState, Bool);
    }

    ~Misc_TwoStateRotater() override = default;

    // === Lifecycle Methods ===
    void Awake() override {}

    void Initialize(Entity entity) override {}

    void Start() override {
        currentState = startingState;
        CacheTarget();
        if (!targetTransformRef.IsValid()) {
            LOG_WARNING("Misc_TwoStateRotater: target not set or invalid");
            return;
        }

        Vec3 initialRotation = GetRotation(targetTransformRef);
        firstState = Vec3(rotationX1, initialRotation.y, initialRotation.z);
        secondState = Vec3(rotationX2, initialRotation.y, initialRotation.z);
        ApplyStateImmediate();
    }

    void Update(double deltaTime) override {}

    void OnDestroy() override {}

    // === Optional Callbacks ===
    void OnEnable() override {}
    void OnDisable() override {}
    void OnValidate() override {}

    const char* GetTypeName() const override {
        return "Misc_TwoStateRotater";
    }

    // === Collision Callbacks ===
    void OnCollisionEnter(Entity other) override { (void)other; }
    void OnCollisionExit(Entity other) override { (void)other; }
    void OnCollisionStay(Entity other) override { (void)other; }
    void OnTriggerEnter(Entity other) override { (void)other; }
    void OnTriggerExit(Entity other) override { (void)other; }
    void OnTriggerStay(Entity other) override { (void)other; }

    // === Public API (for other scripts or events) ===
    void SwitchState() {
        currentState = !currentState;
        LOG_INFO("Puzzle_TwoStateRotater: SwitchState -> " << (currentState ? "state1" : "state2"));
        ApplyStateTweened();
    }

    void SetState(bool state) {
        currentState = state;
        LOG_INFO("Puzzle_TwoStateRotater: SetState -> " << (currentState ? "state1" : "state2"));
        ApplyStateTweened();
    }

    bool GetStartingState() const {
        return startingState;
    }

private:
    GameObjectRef target;
    TransformRef targetTransformRef;
    Entity targetEntity = NE::Scripting::INVALID_ENTITY;
    float rotationX1 = 0.0f;
    float rotationX2 = 0.0f;
    float duration = 0.0f;
    bool startingState = false;

    Vec3 firstState = Vec3::Zero(); // Quaternion
    Vec3 secondState = Vec3::Zero(); // Quaternion
    bool currentState = false;

    void CacheTarget() {
        if (target.IsValid()) {
            targetEntity = target.GetEntity();
            targetTransformRef = GetTransformRef(targetEntity);
        }
        else {
            targetEntity = GetEntity();
            targetTransformRef = GetTransformRef(targetEntity);
        }
    }

    Vec3 GetTargetRotation() const {
        return currentState ? firstState : secondState;
    }

    void ApplyStateImmediate() {
        if (!targetTransformRef.IsValid()) {
            return;
        }
        TF_SetRotation(GetTargetRotation(), targetEntity);
    }

    void ApplyStateTweened() {
        if (!targetTransformRef.IsValid()) {
            LOG_WARNING("Misc_TwoStateRotater: target invalid while applying state");
            return;
        }

        Vec3 startRotation = TF_GetLocalRotation(targetEntity);
        Vec3 endRotation = GetTargetRotation();

        if (duration <= 0.0f) {
            TF_SetRotation(endRotation, targetEntity);
            return;
        }

        Tweener::StartVec3(
            [this](const Vec3& rot) {
                TF_SetRotation(rot, targetEntity);
            },
            startRotation,
            endRotation,
            duration,
            Tweener::Type::CUBIC_EASE_IN,
            GetEntity()
        );
    }
};
